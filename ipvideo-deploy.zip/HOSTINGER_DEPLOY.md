# Déploiement Hostinger VPS — Ipvideo

## 📦 Fichier prêt : `ipvideo-deploy.zip`

Ce fichier se trouve sur votre Bureau (`C:\Users\Hp\Desktop\ipvideo-deploy.zip`).

---

## Ce qui est dans le zip

```
Ipvideo/
├── client/          ← Frontend (HTML, CSS, JS) — site visible
├── server/          ← Backend (Node.js, Express, API)
├── docker-compose.yml
├── nginx.conf
├── Dockerfile
└── deploy-hostinger.sh
```

**⚠️ Le fichier `.env` et `node_modules` ont été retirés pour la sécurité.**
Vous devrez recréer le `.env` sur le VPS.

---

## 🚀 Étapes de déploiement sur Hostinger VPS

### Étape 1 : Acheter le VPS Hostinger

1. Allez sur https://www.hostinger.fr/vps
2. Choisissez le plan **KVM 1** (à partir de ~4,99€/mois) — suffisant pour démarrer
3. Choisissez **Ubuntu 22.04** comme système d'exploitation
4. Complétez l'achat

---

### Étape 2 : Se connecter au VPS

Hostinger vous enverra par email :
- **IP du serveur** (ex: `123.456.789.100`)
- **Mot de passe root**

**Option A : Terminal (PowerShell ou Git Bash)**
```bash
ssh root@123.456.789.100
# Entrez le mot de passe quand demandé
```

**Option B : PuTTY** (Windows)
- Téléchargez PuTTY : https://putty.org
- Host Name : `root@123.456.789.100`
- Port : `22`
- Cliquez **Open**

---

### Étape 3 : Uploader le zip sur le VPS

**Option A : via SCP (Terminal)**
```bash
scp C:\Users\Hp\Desktop\ipvideo-deploy.zip root@123.456.789.100:/root/
```

**Option B : via FileZilla**
- Téléchargez FileZilla Client
- Host : `123.456.789.100`
- Username : `root`
- Password : votre_mot_de_passe
- Port : `22`
- Glissez-déposez `ipvideo-deploy.zip` dans `/root/`

---

### Étape 4 : Installer Docker et Docker Compose

Connecté au VPS en SSH, tapez :

```bash
# Mettre à jour le système
apt-get update && apt-get upgrade -y

# Installer Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sh get-docker.sh

# Vérifier Docker
docker --version

# Installer Docker Compose
apt-get install -y docker-compose-plugin

# Démarrer Docker
systemctl enable docker
systemctl start docker
```

---

### Étape 5 : Extraire et configurer l'application

```bash
# Aller dans /root
cd /root

# Extraire le zip
apt-get install -y unzip
unzip ipvideo-deploy.zip

# Aller dans le dossier
cd Ipvideo

# Créer le fichier .env
nano server/.env
```

**Copiez-collez CE CONTENU EXACT dans le fichier .env :**

```env
NODE_ENV=production
PORT=5000
CLIENT_URL=https://votredomaine.com

# Supabase (vos vraies clés)
SUPABASE_URL=https://sxkclerokwzwakjjxony.supabase.co
SUPABASE_SERVICE_ROLE_KEY=sb_secret_sCC13Jz8xUUUZI7r0PJPag_J-3tn2au

# JWT (générez une clé sécurisée)
JWT_SECRET=ipvideo_production_secret_change_this_to_a_random_string_123456789
JWT_EXPIRE=7d

# PayPal (vos vraies clés)
PAYPAL_CLIENT_ID=BAAN7WxbDxhJSAsU1qIdwz0tOnYJiy8MNvu0BB67-EZ7sVyyxbHBa3F62CtP1E_aDn2OaBdHrPDSWnlNnQ
PAYPAL_CLIENT_SECRET=EBmQDAaqCzhNUS1kwfJpsXilqIe8VcVubwVwiUWYUsPtYqsqhnn9pqq4axBWH6ZZOpBA9OrF8eGWSZE9
PAYPAL_PLAN_PRO_ID=P-05L36682RB3103432NKFXTKY
PAYPAL_PLAN_ENTERPRISE_ID=P-7LS12504PX9291133NKFXTLA
PAYPAL_WEBHOOK_ID=

# Replicate AI
génération vidéo
REPLICATE_API_TOKEN=votre_token_replicate_ici

# Cloudinary (optionnel)
CLOUDINARY_CLOUD_NAME=
CLOUDINARY_API_KEY=
CLOUDINARY_API_SECRET=
```

**Remplacez :**
- `votredomaine.com` par votre vrai domaine
- `votre_token_replicate_ici` par votre token Replicate (https://replicate.com/account/api-tokens)
- Générez un nouveau `JWT_SECRET` sécurisé (ex: sur https://jwtsecret.com)

Sauvegardez : `Ctrl+O` puis `Enter`, puis `Ctrl+X`

---

### Étape 6 : Lancer l'application avec Docker

```bash
# Dans le dossier Ipvideo
cd /root/Ipvideo

# Construire et démarrer
docker-compose up -d --build

# Vérifier que tout fonctionne
docker-compose ps
docker-compose logs -f
```

L'application est maintenant accessible sur :
- **Backend API** : `http://123.456.789.100:5000`
- **Frontend** : `http://123.456.789.100:3000`

---

### Étape 7 : Configurer le domaine

**Achetez un domaine** (si vous n'en avez pas) :
- Hostinger Domain : ~1€ la première année
- Namecheap, OVH, GoDaddy...

**Pointer le domaine vers votre VPS :**
1. Dans le panel de gestion de votre domaine, allez dans **DNS**
2. Ajoutez un enregistrement **A** :
   - Nom : `@` (ou `www`)
   - Valeur : `123.456.789.100` (IP de votre VPS)
   - TTL : 3600

Attendez 5-30 minutes que la propagation DNS se fasse.

---

### Étape 8 : Configurer Nginx + SSL (HTTPS)

```bash
# Installer Nginx
apt-get install -y nginx certbot python3-certbot-nginx

# Copier la configuration
cp /root/Ipvideo/nginx.conf /etc/nginx/sites-available/ipvideo

# Remplacez 'votredomaine.com' par votre vrai domaine
sed -i 's/votredomaine.com/votre-vrai-domaine.com/g' /etc/nginx/sites-available/ipvideo

# Activer le site
ln -s /etc/nginx/sites-available/ipvideo /etc/nginx/sites-enabled/
rm /etc/nginx/sites-enabled/default

# Tester la config
nginx -t

# Redémarrer Nginx
systemctl restart nginx

# Installer SSL (HTTPS)
certbot --nginx -d votre-vrai-domaine.com -d www.votre-vrai-domaine.com

# Suivez les instructions de Certbot
```

**✅ Votre site est maintenant accessible en HTTPS !**

---

### Étape 9 : Configurer le Webhook PayPal

Maintenant que vous avez un vrai domaine :

1. Allez sur https://developer.paypal.com → Dashboard → App Ipvideo
2. **Webhooks** → **Add Webhook**
3. URL : `https://votre-vrai-domaine.com/api/payments/webhook`
4. Événements :
   - ✅ Billing subscription activated
   - ✅ Billing subscription cancelled
   - ✅ Payment sale completed
5. **Save**
6. Copiez le **Webhook ID** affiché
7. Éditez le `.env` sur le VPS :
   ```bash
   nano /root/Ipvideo/server/.env
   # Ajoutez: PAYPAL_WEBHOOK_ID=votre_webhook_id
   ```
8. Redémarrez :
   ```bash
   cd /root/Ipvideo && docker-compose restart
   ```

---

## 🔧 Commandes utiles après déploiement

```bash
# Voir les logs en temps réel
cd /root/Ipvideo && docker-compose logs -f

# Redémarrer l'application
docker-compose restart

# Mettre à jour (après modification du code)
docker-compose up -d --build

# Arrêter l'application
docker-compose down

# Voir l'espace disque
df -h

# Voir les processus
docker stats
```

---

## 🆘 Dépannage

| Problème | Solution |
|----------|----------|
| Site ne charge pas | Vérifiez le firewall : `ufw allow 80 && ufw allow 443 && ufw allow 5000` |
| Erreur 502 Bad Gateway | `docker-compose ps` — le backend doit être "Up" |
| Certbot échoue | Assurez-vous que le DNS pointe bien vers le VPS |
| Port 5000 déjà utilisé | `lsof -ti:5000 | xargs kill -9` |
| Problèmes de permissions | `chmod -R 755 /root/Ipvideo` |

---

## 📞 Besoin d'aide ?

- **Hostinger Support** : chat 24/7 dans votre panel
- **Documentation Docker** : https://docs.docker.com
- **Certbot** : https://certbot.eff.org

**Votre application est prête à être déployée ! 🚀**
